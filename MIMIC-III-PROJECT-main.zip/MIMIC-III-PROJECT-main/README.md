# MIMIC-III

## Brief introduction

The repository consists of a number of Structured Query Language (SQL) scripts which build the MIMIC-III database in a number of systems and extract useful concepts from the raw data.
Jupyter notebooks are also provided which detail analyses performed on MIMIC-III.
